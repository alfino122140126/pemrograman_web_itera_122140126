import React from "react";
import useBookStats from "../../hooks/useBookStats";

const Stats = () => {
  const { total, owned, reading, wantToBuy } = useBookStats();

  return (
    <div style={{ padding: "1rem" }}>
      <h1>Statistik Buku</h1>
      <ul>
        <li>Total Buku: {total}</li>
        <li>Dimiliki: {owned}</li>
        <li>Sedang Dibaca: {reading}</li>
        <li>Ingin Dibeli: {wantToBuy}</li>
      </ul>
    </div>
  );
};

export default Stats;
