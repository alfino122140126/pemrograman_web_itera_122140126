import React from "react";
import BookForm from "../../components/BookForm/BookForm";
import BookFilter from "../../components/BookFilter/BookFilter";
import BookList from "../../components/BookList/BookList";

const Home = () => {
  return (
    <div style={{ padding: "1rem" }}>
      <h1>Manajemen Buku Pribadi</h1>
      <BookForm />
      <BookFilter />
      <BookList />
    </div>
  );
};

export default Home;
