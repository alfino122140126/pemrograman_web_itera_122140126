import { useContext, useMemo } from "react";
import { BookContext } from "../context/BookContext";

const useBookStats = () => {
  const { books } = useContext(BookContext);

  return useMemo(() => {
    return {
      total: books.length,
      owned: books.filter((book) => book.status === "milik").length,
      reading: books.filter((book) => book.status === "baca").length,
      wantToBuy: books.filter((book) => book.status === "beli").length,
    };
  }, [books]);
};

export default useBookStats;
