import React, { useState } from "react";
import "./BookFilter.css";

const BookFilter = ({ onFilter }) => {
  const [status, setStatus] = useState("");

  const handleChange = (e) => {
    setStatus(e.target.value);
    onFilter(e.target.value);
  };

  return (
    <div style={{ marginBottom: "1rem" }}>
      <label>Filter Status: </label>
      <select value={status} onChange={handleChange}>
        <option value="">Semua</option>
        <option value="milik">Dimiliki</option>
        <option value="baca">Sedang Dibaca</option>
        <option value="beli">Ingin Dibeli</option>
      </select>
    </div>
  );
};

export default BookFilter;
