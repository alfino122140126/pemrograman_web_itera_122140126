import React, { useState, useContext } from "react";
import { BookContext } from "../../context/BookContext";
import PropTypes from "prop-types";
import "./BookForm.css";

const BookForm = ({ editBook, onEditComplete }) => {
  const { addBook, updateBook } = useContext(BookContext);
  const [title, setTitle] = useState(editBook ? editBook.title : "");
  const [author, setAuthor] = useState(editBook ? editBook.author : "");
  const [status, setStatus] = useState(editBook ? editBook.status : "milik");
  const [error, setError] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title || !author) {
      setError("Judul dan Penulis wajib diisi.");
      return;
    }
    const book = {
      id: editBook ? editBook.id : Date.now(),
      title,
      author,
      status,
    };
    editBook ? updateBook(book) : addBook(book);
    setTitle("");
    setAuthor("");
    setStatus("milik");
    setError("");
    if (onEditComplete) onEditComplete();
  };

  return (
    <form onSubmit={handleSubmit} style={{ marginBottom: "1rem" }}>
      <h2>{editBook ? "Edit Buku" : "Tambah Buku"}</h2>
      {error && <p style={{ color: "red" }}>{error}</p>}
      <input
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Judul"
      />
      <input
        value={author}
        onChange={(e) => setAuthor(e.target.value)}
        placeholder="Penulis"
      />
      <select value={status} onChange={(e) => setStatus(e.target.value)}>
        <option value="milik">Dimiliki</option>
        <option value="baca">Sedang Dibaca</option>
        <option value="beli">Ingin Dibeli</option>
      </select>
      <button type="submit">{editBook ? "Simpan" : "Tambah"}</button>
    </form>
  );
};

BookForm.propTypes = {
  editBook: PropTypes.object,
  onEditComplete: PropTypes.func,
};

export default BookForm;
