import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import BookForm from "./BookForm";
import { BookContext } from "../../context/BookContext";

const mockAddBook = jest.fn();
const mockUpdateBook = jest.fn();

const renderWithContext = (component) => {
  return render(
    <BookContext.Provider
      value={{ addBook: mockAddBook, updateBook: mockUpdateBook }}
    >
      {component}
    </BookContext.Provider>
  );
};

test("renders BookForm and submits new book", () => {
  renderWithContext(<BookForm />);
  fireEvent.change(screen.getByPlaceholderText(/judul/i), {
    target: { value: "React Book" },
  });
  fireEvent.change(screen.getByPlaceholderText(/penulis/i), {
    target: { value: "Jordan" },
  });
  fireEvent.change(screen.getByDisplayValue(/dimiliki/i), {
    target: { value: "baca" },
  });
  fireEvent.click(screen.getByText(/tambah/i));
  expect(mockAddBook).toHaveBeenCalled();
});

test("shows error when fields are empty", () => {
  renderWithContext(<BookForm />);
  fireEvent.click(screen.getByText(/tambah/i));
  expect(screen.getByText(/wajib diisi/i)).toBeInTheDocument();
});

test("renders BookForm with editBook prop", () => {
  const editBook = {
    id: 1,
    title: "Old Title",
    author: "Old Author",
    status: "beli",
  };
  renderWithContext(<BookForm editBook={editBook} />);
  expect(screen.getByDisplayValue(/Old Title/i)).toBeInTheDocument();
  expect(screen.getByDisplayValue(/Old Author/i)).toBeInTheDocument();
});

test("updates book when editing", () => {
  const editBook = {
    id: 1,
    title: "Edit Me",
    author: "Editor",
    status: "milik",
  };
  renderWithContext(<BookForm editBook={editBook} />);
  fireEvent.click(screen.getByText(/simpan/i));
  expect(mockUpdateBook).toHaveBeenCalled();
});

test("resets form after submit", () => {
  renderWithContext(<BookForm />);
  fireEvent.change(screen.getByPlaceholderText(/judul/i), {
    target: { value: "Clean Code" },
  });
  fireEvent.change(screen.getByPlaceholderText(/penulis/i), {
    target: { value: "Robert Martin" },
  });
  fireEvent.click(screen.getByText(/tambah/i));
  expect(screen.getByPlaceholderText(/judul/i).value).toBe("");
  expect(screen.getByPlaceholderText(/penulis/i).value).toBe("");
});
