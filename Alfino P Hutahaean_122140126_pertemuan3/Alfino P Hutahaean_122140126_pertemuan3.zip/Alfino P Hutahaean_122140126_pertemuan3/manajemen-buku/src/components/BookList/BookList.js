import React, { useContext, useState } from "react";
import { BookContext } from "../../context/BookContext";
import BookForm from "../BookForm/BookForm";
import "./BookList.css";

const BookList = () => {
  const { books, deleteBook } = useContext(BookContext);
  const [filter, setFilter] = useState("");
  const [search, setSearch] = useState("");
  const [editBook, setEditBook] = useState(null);

  const filteredBooks = books.filter(
    (book) =>
      (filter === "" || book.status === filter) &&
      (book.title.toLowerCase().includes(search.toLowerCase()) ||
        book.author.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div>
      <input
        type="text"
        placeholder="Cari judul atau penulis..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        style={{ marginBottom: "1rem" }}
      />
      <BookForm editBook={editBook} onEditComplete={() => setEditBook(null)} />
      <ul>
        {filteredBooks.map((book) => (
          <li key={book.id}>
            <strong>{book.title}</strong> oleh {book.author} [{book.status}]
            <button onClick={() => setEditBook(book)}>Edit</button>
            <button onClick={() => deleteBook(book.id)}>Hapus</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default BookList;
