import React, { createContext, useState } from "react";
import useLocalStorage from "../hooks/useLocalStorage";

export const BookContext = createContext();

export const BookProvider = ({ children }) => {
  const [books, setBooks] = useLocalStorage("books", []);

  const addBook = (book) => setBooks((prev) => [...prev, book]);
  const deleteBook = (id) =>
    setBooks((prev) => prev.filter((book) => book.id !== id));
  const updateBook = (updatedBook) => {
    setBooks((prev) =>
      prev.map((book) => (book.id === updatedBook.id ? updatedBook : book))
    );
  };

  return (
    <BookContext.Provider value={{ books, addBook, deleteBook, updateBook }}>
      {children}
    </BookContext.Provider>
  );
};
